<?php

declare(strict_types=1);

namespace App\Services\Subscribe;

abstract class Base
{
    abstract public function getContent($user): string;

    /**
     * 客户端实际连接的地址（vmess 的 add、clash 的 server、sing-box 的 server 等）。
     * 优先取节点 custom_config 里的 server_user（CDN / 中转地址），没填则回退到节点表的 server。
     */
    public static function host(object $node, ?array $config = null): string
    {
        if ($config === null) {
            $config = json_decode((string) ($node->custom_config ?? ''), true);
        }

        $candidate = is_array($config) ? ($config['server_user'] ?? '') : '';
        if (is_string($candidate) && trim($candidate) !== '') {
            // 容错：允许误填 https://cdn.example.com/ 之类，只取 host[:port]
            $host = (string) preg_replace('#^[a-z][a-z0-9+.\-]*://#i', '', trim($candidate));
            $host = explode('/', $host)[0];
            if ($host !== '') {
                return $host;
            }
        }

        return (string) $node->server;
    }

    /** Isolate invalid VLESS nodes without logging credentials or private keys. */
    protected function vlessClient(object $node, mixed $config): ?array
    {
        if (! is_array($config)) {
            return null;
        }

        try {
            // server 只作为 sni / server_name 的兜底，连接地址在 Vless::uri() 里单独取
            return Vless::client($config, (string) $node->server);
        } catch (\InvalidArgumentException | \RuntimeException $error) {
            error_log('Skipped invalid VLESS subscription node id=' . (int) $node->id);

            return null;
        }
    }
}
