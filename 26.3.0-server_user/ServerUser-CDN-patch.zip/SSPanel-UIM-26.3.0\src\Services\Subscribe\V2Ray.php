<?php

declare(strict_types=1);

namespace App\Services\Subscribe;

use App\Models\Config;
use App\Services\Subscribe;
use function base64_encode;
use function json_decode;
use function json_encode;
use const PHP_EOL;

final class V2Ray extends Base
{
    public function getContent($user): string
    {
        $links = '';
        //判断是否开启V2Ray订阅
        if (! Config::obtain('enable_v2_sub')) {
            return $links;
        }

        $nodes_raw = Subscribe::getUserNodes($user);

        foreach ($nodes_raw as $node_raw) {
            $node_custom_config = json_decode($node_raw->custom_config, true);

            if ((int) $node_raw->sort === 11) {
                if (Vless::enabled($node_custom_config)) {
                    $client = $this->vlessClient($node_raw, $node_custom_config);
                    if ($client === null) {
                        continue;
                    }
                    $links .= Vless::uri($node_raw, $user, $node_custom_config, $client) . PHP_EOL;
                    continue;
                }

                $v2_port = $node_custom_config['offset_port_user'] ?? ($node_custom_config['offset_port_node'] ?? 443);
                $security = $node_custom_config['security'] ?? 'none';
                $network = $node_custom_config['network'] ?? '';
                $header = $node_custom_config['header'] ?? ['type' => 'none'];
                $header_type = $header['type'] ?? '';
                $host = $node_custom_config['header']['request']['headers']['Host'][0] ?? $node_custom_config['host'] ?? '';
                // v2rayN share links carry the gRPC service name in path.
                $path = $network === 'grpc' ? ($node_custom_config['servicename'] ?? '') :
                    ($node_custom_config['header']['request']['path'][0] ?? $node_custom_config['path'] ?? '/');

                $v2rayn_array = [
                    'v' => '2',
                    'ps' => $node_raw->name,
                    'add' => self::host($node_raw, $node_custom_config),
                    'port' => $v2_port,
                    'id' => $user->uuid,
                    'aid' => 0,
                    'net' => $network,
                    'type' => $header_type,
                    'host' => $host,
                    'path' => $path,
                    'tls' => $security,
                ];

                $links .= 'vmess://' . base64_encode(json_encode($v2rayn_array)) . PHP_EOL;
            } elseif ((int) $node_raw->sort === 15) {
                $uri = Hysteria2::buildUri($node_raw, $user);
                if ($uri !== null) {
                    $links .= $uri . PHP_EOL;
                }
            }
        }

        return $links;
    }
}
